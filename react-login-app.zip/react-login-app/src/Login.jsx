import { useState } from "react";

// Predefined credentials (no database needed for this assignment)
const VALID_USERNAME = "admin";
const VALID_PASSWORD = "admin123";

export default function Login({ onLoginSuccess }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault(); // stop the page from reloading

    if (!username.trim() || !password) {
      setError("Please enter username and password.");
      return;
    }

    if (username === VALID_USERNAME && password === VALID_PASSWORD) {
      setError("");
      onLoginSuccess(); // tell App to show the Home page
    } else {
      setError("Invalid username or password.");
      setPassword(""); // clear password, stay on the Login page
    }
  };

  return (
    <main className="login-page">
      <form className="login-card" onSubmit={handleSubmit} noValidate>
        <h1>Sign in</h1>
        <p className="login-sub">Enter your credentials to open the dashboard.</p>

        <label htmlFor="username">Username</label>
        <input
          id="username"
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          autoComplete="username"
          autoFocus
        />

        <label htmlFor="password">Password</label>
        <input
          id="password"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          autoComplete="current-password"
        />

        {error && (
          <p className="login-error" role="alert">
            {error}
          </p>
        )}

        <button type="submit">Log in</button>
      </form>
    </main>
  );
}
