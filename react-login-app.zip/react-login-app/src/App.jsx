import { useState } from "react";
import Login from "./Login.jsx";
import Home from "./Home.jsx"; // existing Home page - unchanged

export default function App() {
  // false = show Login page, true = show Home page
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  if (!isLoggedIn) {
    return <Login onLoginSuccess={() => setIsLoggedIn(true)} />;
  }
  return <Home />;
}
