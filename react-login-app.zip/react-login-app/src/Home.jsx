import { useState } from "react";

// Stand-in for the already-existing Home page.
// Replace this file with your real Home page; nothing else needs to change.
export default function Home() {
  const [count, setCount] = useState(0);

  return (
    <main className="home-page">
      <h1>Welcome to the Home page</h1>
      <p>This is the existing application page.</p>
      <button onClick={() => setCount(count + 1)}>Clicked {count} times</button>
    </main>
  );
}
