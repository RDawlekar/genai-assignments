# React Login App

## Run
```bash
npm install
npm run dev
```
Open the URL shown in the terminal (usually http://localhost:5173).

## Test
| Username | Password   | Expected result                                   |
|----------|------------|---------------------------------------------------|
| admin    | admin123   | Home page is displayed                            |
| admin    | wrong      | "Invalid username or password." - stays on Login  |
| (blank)  | (blank)    | "Please enter username and password."             |

## Files
- `src/Login.jsx` - NEW: login form, validation, hardcoded credentials
- `src/App.jsx`   - MODIFIED: shows Login first, then Home after success
- `src/Home.jsx`  - EXISTING: unchanged (stand-in included; replace with yours)
